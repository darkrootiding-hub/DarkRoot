// =============================================================
// SINGLE SOURCE OF TRUTH
// Edit everything here — name, bio, skills, projects, experience,
// resume link, and social links — the whole site reads from this file.
// =============================================================

export const profile = {
  name: 'David Stha',
  brand: 'DarkRoot Organizations',
  titles: [
    'Full-Stack Developer',
    'AI Engineer',
    'UI/UX Designer',
    'Open-Source Developer',
    'Founder of DarkRoot Organizations',
  ],
  bio: `I am a passionate software developer and AI enthusiast focused on building modern web applications, AI-powered tools, automation systems, and open-source projects. My mission is to create innovative technology that solves real-world problems through clean design, intelligent software, and exceptional user experiences.`,
  location: 'Available worldwide · Remote-first',
  avatar: '/avatar.jpg',
  resumeUrl: '/resume.pdf',
  email: 'hello@darkroot.dev',
  stats: [
    { label: 'Years Building', value: 4, suffix: '+' },
    { label: 'Projects Shipped', value: 32, suffix: '+' },
    { label: 'Open-Source Repos', value: 18, suffix: '' },
    { label: 'Happy Clients', value: 12, suffix: '+' },
  ],
};

export const socials = [
  { name: 'GitHub', url: 'https://github.com/davidstha', icon: 'github' },
  { name: 'LinkedIn', url: 'https://linkedin.com/in/davidstha', icon: 'linkedin' },
  { name: 'X', url: 'https://x.com/davidstha', icon: 'x' },
  { name: 'Instagram', url: 'https://instagram.com/davidstha', icon: 'instagram' },
  { name: 'Email', url: 'mailto:hello@darkroot.dev', icon: 'mail' },
];

export const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Skills', href: '#skills' },
  { label: 'Projects', href: '#projects' },
  { label: 'Experience', href: '#experience' },
  { label: 'Certifications', href: '#certifications' },
  { label: 'Services', href: '#services' },
  { label: 'Blog', href: '#blog' },
  { label: 'Contact', href: '#contact' },
];

export type SkillCategory = 'Frontend' | 'Backend' | 'AI & Data' | 'Tools & Platforms';

export const skills: { name: string; level: number; category: SkillCategory }[] = [
  { name: 'React', level: 95, category: 'Frontend' },
  { name: 'JavaScript', level: 95, category: 'Frontend' },
  { name: 'TypeScript', level: 88, category: 'Frontend' },
  { name: 'HTML', level: 98, category: 'Frontend' },
  { name: 'CSS / Tailwind', level: 93, category: 'Frontend' },
  { name: 'Node.js', level: 90, category: 'Backend' },
  { name: 'Express.js', level: 87, category: 'Backend' },
  { name: 'REST APIs', level: 92, category: 'Backend' },
  { name: 'Firebase', level: 85, category: 'Backend' },
  { name: 'Python', level: 86, category: 'AI & Data' },
  { name: 'AI Integration', level: 89, category: 'AI & Data' },
  { name: 'Git & GitHub', level: 94, category: 'Tools & Platforms' },
  { name: 'UI/UX Design', level: 88, category: 'Tools & Platforms' },
];

export const projects = [
  {
    id: 'proj-neural-forge',
    title: 'NeuralForge',
    description: 'An AI-powered automation suite that turns natural language into working workflows, with a visual node editor and live execution graph.',
    tags: ['React', 'Node.js', 'AI Integration', 'Firebase'],
    image: '/projects/neuralforge.jpg',
    github: 'https://github.com/davidstha/neuralforge',
    demo: 'https://neuralforge.darkroot.dev',
    featured: true,
  },
  {
    id: 'proj-rootstack',
    title: 'RootStack CMS',
    description: 'An open-source, config-driven headless CMS built for developer portfolios and small teams shipping fast.',
    tags: ['TypeScript', 'Express.js', 'REST APIs'],
    image: '/projects/rootstack.jpg',
    github: 'https://github.com/davidstha/rootstack',
    demo: 'https://rootstack.darkroot.dev',
    featured: true,
  },
  {
    id: 'proj-pulseboard',
    title: 'PulseBoard',
    description: 'Real-time analytics dashboard with WebSocket-driven live metrics, custom charting, and role-based access.',
    tags: ['React', 'Node.js', 'WebSockets'],
    image: '/projects/pulseboard.jpg',
    github: 'https://github.com/davidstha/pulseboard',
    demo: 'https://pulseboard.darkroot.dev',
    featured: false,
  },
  {
    id: 'proj-lumenchat',
    title: 'LumenChat',
    description: 'A privacy-first AI chat client with local-first storage, prompt libraries, and multi-model routing.',
    tags: ['Python', 'AI Integration', 'React'],
    image: '/projects/lumenchat.jpg',
    github: 'https://github.com/davidstha/lumenchat',
    demo: 'https://lumenchat.darkroot.dev',
    featured: true,
  },
  {
    id: 'proj-formflow',
    title: 'FormFlow',
    description: 'Drag-and-drop form builder with validation logic, conditional fields, and one-click API export.',
    tags: ['React', 'TypeScript', 'Tailwind CSS'],
    image: '/projects/formflow.jpg',
    github: 'https://github.com/davidstha/formflow',
    demo: 'https://formflow.darkroot.dev',
    featured: false,
  },
  {
    id: 'proj-orbitkit',
    title: 'OrbitKit UI',
    description: 'An open-source component library of glassmorphic, motion-ready React components for futuristic interfaces.',
    tags: ['React', 'Tailwind CSS', 'Framer Motion'],
    image: '/projects/orbitkit.jpg',
    github: 'https://github.com/davidstha/orbitkit',
    demo: 'https://orbitkit.darkroot.dev',
    featured: false,
  },
];

export type TimelineType = 'education' | 'experience' | 'certification' | 'award';

export const timeline: {
  id: string;
  type: TimelineType;
  title: string;
  org: string;
  period: string;
  description: string;
}[] = [
  {
    id: 't1',
    type: 'experience',
    title: 'Founder & Lead Developer',
    org: 'DarkRoot Organizations',
    period: '2023 — Present',
    description: 'Founded DarkRoot to build AI-powered tools and open-source software. Leading product, architecture, and design across the studio\'s projects.',
  },
  {
    id: 't2',
    type: 'experience',
    title: 'Full-Stack Developer (Freelance)',
    org: 'Independent',
    period: '2021 — 2023',
    description: 'Delivered full-stack web applications for startups and small businesses, from API design to production deployment.',
  },
  {
    id: 't3',
    type: 'education',
    title: 'B.Sc. Computer Science',
    org: 'University',
    period: '2019 — 2023',
    description: 'Focused on software engineering, distributed systems, and applied machine learning.',
  },
  {
    id: 't4',
    type: 'certification',
    title: 'AI Engineering Professional Certificate',
    org: 'Independent Study / Online Cert',
    period: '2023',
    description: 'Deep dive into applied AI integration, prompt engineering, and production ML systems.',
  },
  {
    id: 't5',
    type: 'award',
    title: 'Open-Source Contributor Recognition',
    org: 'GitHub Community',
    period: '2024',
    description: 'Recognized for sustained contributions across multiple open-source repositories.',
  },
];

export const services = [
  {
    title: 'Web Application Development',
    description: 'End-to-end React and Node.js applications, from architecture to deployment.',
    icon: 'code',
  },
  {
    title: 'AI Tool Integration',
    description: 'Embedding AI-powered features — chat, automation, generation — into real products.',
    icon: 'cpu',
  },
  {
    title: 'UI/UX Design',
    description: 'Interfaces that feel intentional: clear systems, motion with purpose, accessible by default.',
    icon: 'layout',
  },
  {
    title: 'Open-Source Consulting',
    description: 'Helping teams design, maintain, and grow sustainable open-source projects.',
    icon: 'git-branch',
  },
];

export const testimonials = [
  {
    name: 'Anika Rai',
    role: 'Product Lead, Nimbus Labs',
    quote: 'David turned a vague idea into a polished product in weeks. The attention to detail in both code and design was rare.',
    avatar: '/testimonials/anika.jpg',
  },
  {
    name: 'Marcus Chen',
    role: 'CTO, Fieldstack',
    quote: 'One of the few developers who can move fluidly between backend architecture and frontend polish without losing quality.',
    avatar: '/testimonials/marcus.jpg',
  },
  {
    name: 'Priya Sharma',
    role: 'Founder, Loop Studio',
    quote: 'DarkRoot delivered an AI integration that just worked — fast, reliable, and genuinely useful for our users.',
    avatar: '/testimonials/priya.jpg',
  },
];

export const blogPosts = [
  {
    id: 'post-1',
    title: 'Designing Interfaces That Feel Alive',
    excerpt: 'Notes on motion design, restraint, and when animation actually helps a product feel better to use.',
    date: '2026-04-12',
    readTime: '6 min read',
    tag: 'Design',
  },
  {
    id: 'post-2',
    title: 'Shipping AI Features Without the Hype',
    excerpt: 'A practical framework for deciding when AI integration adds real value versus when it\'s noise.',
    date: '2026-02-03',
    readTime: '8 min read',
    tag: 'AI Engineering',
  },
  {
    id: 'post-3',
    title: 'Why I Open-Source Almost Everything',
    excerpt: 'The long-term case for building in public, even when it feels slower at first.',
    date: '2025-11-18',
    readTime: '5 min read',
    tag: 'Open Source',
  },
];

export const seo = {
  title: 'David Stha — Full-Stack Developer & AI Engineer',
  description:
    'Portfolio of David Stha, Founder of DarkRoot Organizations — full-stack development, AI integration, and UI/UX design.',
};
