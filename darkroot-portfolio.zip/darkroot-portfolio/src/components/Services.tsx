import { FiCode, FiCpu, FiLayout, FiGitBranch } from 'react-icons/fi';
import { services } from '../data/config';
import { Reveal, SectionHeading } from './Reveal';

const iconMap: Record<string, JSX.Element> = {
  code: <FiCode />,
  cpu: <FiCpu />,
  layout: <FiLayout />,
  'git-branch': <FiGitBranch />,
};

export default function Services() {
  return (
    <section id="services" className="relative py-28">
      <SectionHeading eyebrow="Services" title="How I can help" />
      <div className="mx-auto grid max-w-6xl gap-6 px-6 sm:grid-cols-2 lg:grid-cols-4">
        {services.map((s, i) => (
          <Reveal key={s.title} delay={i * 0.08}>
            <div className="glass group h-full rounded-3xl p-7 transition-all duration-300 hover:-translate-y-1 hover:shadow-glow">
              <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-violet/25 to-cyan/15 text-xl text-cyan transition-transform group-hover:scale-110">
                {iconMap[s.icon]}
              </div>
              <h3 className="font-display text-lg font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm text-muted">{s.description}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
