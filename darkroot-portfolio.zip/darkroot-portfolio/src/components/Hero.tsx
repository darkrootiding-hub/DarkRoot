import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { FiGithub, FiLinkedin, FiTwitter, FiInstagram, FiMail, FiDownload, FiChevronDown } from 'react-icons/fi';
import RootScene from './RootScene';
import { profile, socials } from '../data/config';

const iconMap: Record<string, JSX.Element> = {
  github: <FiGithub />,
  linkedin: <FiLinkedin />,
  x: <FiTwitter />,
  instagram: <FiInstagram />,
  mail: <FiMail />,
};

function useTypingEffect(words: string[], speed = 55, pause = 1600) {
  const [text, setText] = useState('');
  const [wordIndex, setWordIndex] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const current = words[wordIndex % words.length];
    let timeout: number;

    if (!deleting && text.length < current.length) {
      timeout = window.setTimeout(() => setText(current.slice(0, text.length + 1)), speed);
    } else if (!deleting && text.length === current.length) {
      timeout = window.setTimeout(() => setDeleting(true), pause);
    } else if (deleting && text.length > 0) {
      timeout = window.setTimeout(() => setText(current.slice(0, text.length - 1)), speed / 1.6);
    } else {
      setDeleting(false);
      setWordIndex((i) => i + 1);
    }
    return () => clearTimeout(timeout);
  }, [text, deleting, wordIndex, words, speed, pause]);

  return text;
}

function MagneticButton({ children, className, ...props }: React.ComponentProps<'a'>) {
  const ref = useRef<HTMLAnchorElement>(null);

  function handleMove(e: React.MouseEvent) {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    el.style.transform = `translate(${x * 0.25}px, ${y * 0.25}px)`;
  }
  function reset() {
    if (ref.current) ref.current.style.transform = 'translate(0,0)';
  }

  return (
    <a
      ref={ref}
      onMouseMove={handleMove}
      onMouseLeave={reset}
      className={`magnetic-btn transition-transform duration-200 ease-out ${className ?? ''}`}
      {...props}
    >
      {children}
    </a>
  );
}

export default function Hero() {
  const typed = useTypingEffect(profile.titles);

  return (
    <section id="home" className="relative flex min-h-screen items-center overflow-hidden bg-void">
      {/* Background layers */}
      <div className="absolute inset-0 bg-root-glow" />
      <div className="absolute inset-0 bg-aurora opacity-60" />
      <RootScene />

      <div className="relative z-10 mx-auto grid max-w-6xl gap-10 px-6 pt-24 md:grid-cols-2 md:items-center">
        <div>
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-4 font-mono text-sm text-cyan"
          >
            {profile.brand}
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.7 }}
            className="font-display text-4xl font-semibold leading-tight sm:text-5xl lg:text-6xl"
          >
            Hi, I'm <span className="text-gradient">{profile.name}</span>
          </motion.h1>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="mt-4 h-8 font-mono text-lg text-muted sm:text-xl"
          >
            {typed}
            <span className="animate-pulse text-cyan">|</span>
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.55 }}
            className="mt-6 max-w-lg text-muted"
          >
            {profile.bio}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="mt-8 flex flex-wrap items-center gap-4"
          >
            <MagneticButton
              href="#projects"
              className="rounded-full bg-gradient-to-r from-violet to-cyan px-6 py-3 text-sm font-medium text-void shadow-glow"
            >
              View Projects
            </MagneticButton>
            <MagneticButton
              href={profile.resumeUrl}
              download
              className="flex items-center gap-2 rounded-full border border-white/15 px-6 py-3 text-sm text-ink hover:bg-white/5"
            >
              <FiDownload /> Download Resume
            </MagneticButton>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9 }}
            className="mt-8 flex gap-4"
          >
            {socials.map((s) => (
              <a
                key={s.name}
                href={s.url}
                target="_blank"
                rel="noreferrer"
                aria-label={s.name}
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-lg text-muted transition-colors hover:border-cyan/50 hover:text-cyan"
              >
                {iconMap[s.icon]}
              </a>
            ))}
          </motion.div>
        </div>
      </div>

      <motion.a
        href="#about"
        className="absolute bottom-8 left-1/2 z-10 -translate-x-1/2 text-muted"
        animate={{ y: [0, 8, 0] }}
        transition={{ repeat: Infinity, duration: 1.8 }}
        aria-label="Scroll down"
      >
        <FiChevronDown size={24} />
      </motion.a>
    </section>
  );
}
