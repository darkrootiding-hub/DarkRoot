import { useRef, useMemo, Suspense } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Points, PointMaterial, Line, Environment, Float } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette } from '@react-three/postprocessing';
import * as THREE from 'three';

/**
 * RootCore — the signature element of the site.
 * A glowing central node with branching "root" lines growing outward,
 * echoing the DarkRoot brand. Mouse-reactive rotation + gentle float.
 */
function generateRootBranches(count: number, depth: number) {
  const branches: THREE.Vector3[][] = [];

  function grow(origin: THREE.Vector3, dir: THREE.Vector3, level: number) {
    if (level > depth) return;
    const points: THREE.Vector3[] = [origin.clone()];
    let current = origin.clone();
    let currentDir = dir.clone();
    const segments = 5 + Math.floor(Math.random() * 4);

    for (let i = 0; i < segments; i++) {
      currentDir = currentDir
        .clone()
        .add(new THREE.Vector3((Math.random() - 0.5) * 0.4, (Math.random() - 0.5) * 0.4, (Math.random() - 0.5) * 0.4))
        .normalize();
      current = current.clone().add(currentDir.clone().multiplyScalar(0.35 - level * 0.05));
      points.push(current.clone());
    }
    branches.push(points);

    if (level < depth && Math.random() > 0.3) {
      const branchCount = 1 + Math.floor(Math.random() * 2);
      for (let b = 0; b < branchCount; b++) {
        const newDir = currentDir
          .clone()
          .add(new THREE.Vector3((Math.random() - 0.5) * 1.2, (Math.random() - 0.5) * 1.2, (Math.random() - 0.5) * 1.2))
          .normalize();
        grow(current, newDir, level + 1);
      }
    }
  }

  for (let i = 0; i < count; i++) {
    const dir = new THREE.Vector3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).normalize();
    grow(new THREE.Vector3(0, 0, 0), dir, 0);
  }

  return branches;
}

function RootCore() {
  const groupRef = useRef<THREE.Group>(null);
  const { mouse } = useThree();
  const branches = useMemo(() => generateRootBranches(7, 3), []);

  useFrame((state) => {
    if (!groupRef.current) return;
    const t = state.clock.getElapsedTime();
    groupRef.current.rotation.y = t * 0.08 + mouse.x * 0.4;
    groupRef.current.rotation.x = mouse.y * 0.25;
    groupRef.current.position.y = Math.sin(t * 0.6) * 0.15;
  });

  return (
    <group ref={groupRef}>
      {/* Core node */}
      <mesh>
        <icosahedronGeometry args={[0.55, 2]} />
        <meshStandardMaterial
          color="#6d5bff"
          emissive="#6d5bff"
          emissiveIntensity={2}
          roughness={0.2}
          metalness={0.6}
          wireframe
        />
      </mesh>
      <mesh>
        <icosahedronGeometry args={[0.42, 1]} />
        <meshStandardMaterial color="#3fd0ff" emissive="#3fd0ff" emissiveIntensity={1.4} roughness={0.1} metalness={0.8} />
      </mesh>

      {/* Root branches */}
      {branches.map((pts, i) => (
        <Line
          key={i}
          points={pts}
          color={i % 3 === 0 ? '#3fd0ff' : '#8d7bff'}
          lineWidth={1}
          transparent
          opacity={0.55}
        />
      ))}

      {/* Holographic rings */}
      {[1.4, 1.9, 2.4].map((r, i) => (
        <mesh key={r} rotation={[Math.PI / 2.4 + i * 0.3, i * 0.5, 0]}>
          <torusGeometry args={[r, 0.006, 8, 100]} />
          <meshBasicMaterial color={i % 2 === 0 ? '#3fd0ff' : '#9d8dff'} transparent opacity={0.35} />
        </mesh>
      ))}
    </group>
  );
}

function ParticleField() {
  const ref = useRef<THREE.Points>(null);
  const count = 900;

  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const r = 4 + Math.random() * 6;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      arr[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      arr[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      arr[i * 3 + 2] = r * Math.cos(phi);
    }
    return arr;
  }, []);

  useFrame((state) => {
    if (!ref.current) return;
    ref.current.rotation.y = state.clock.getElapsedTime() * 0.015;
  });

  return (
    <Points ref={ref} positions={positions} stride={3} frustumCulled>
      <PointMaterial transparent color="#8ee9ff" size={0.02} sizeAttenuation depthWrite={false} opacity={0.6} />
    </Points>
  );
}

function GridFloor() {
  return (
    <gridHelper
      args={[40, 40, '#3fd0ff', '#151a2e']}
      position={[0, -3.2, 0]}
      rotation={[0, 0, 0]}
    />
  );
}

export default function RootScene() {
  return (
    <div className="absolute inset-0" aria-hidden="true">
      <Canvas
        camera={{ position: [0, 0, 6], fov: 45 }}
        dpr={[1, 1.8]}
        gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
      >
        <Suspense fallback={null}>
          <ambientLight intensity={0.4} />
          <pointLight position={[4, 4, 4]} intensity={2} color="#6d5bff" />
          <pointLight position={[-4, -2, -3]} intensity={1.5} color="#3fd0ff" />

          <Float speed={1.4} rotationIntensity={0.2} floatIntensity={0.6}>
            <RootCore />
          </Float>

          <ParticleField />
          <GridFloor />
          <Environment preset="night" />

          <EffectComposer>
            <Bloom intensity={0.9} luminanceThreshold={0.15} luminanceSmoothing={0.9} mipmapBlur />
            <Vignette eskil={false} offset={0.15} darkness={0.9} />
          </EffectComposer>
        </Suspense>
      </Canvas>
    </div>
  );
}
