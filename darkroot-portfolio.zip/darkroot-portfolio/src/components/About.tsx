import { FiTarget, FiBookOpen, FiAward } from 'react-icons/fi';
import { profile } from '../data/config';
import { Reveal, SectionHeading } from './Reveal';
import Counter from './Counter';

const highlights = [
  { icon: <FiBookOpen />, title: 'Education', text: 'B.Sc. Computer Science, focused on software engineering & applied ML.' },
  { icon: <FiTarget />, title: 'Career Goals', text: 'Grow DarkRoot into a studio known for thoughtful, AI-native software.' },
  { icon: <FiAward />, title: 'Achievements', text: 'Recognized open-source contributor; 30+ shipped products.' },
];

export default function About() {
  return (
    <section id="about" className="relative py-28">
      <SectionHeading eyebrow="About" title="The person behind the code" />

      <div className="mx-auto grid max-w-6xl gap-10 px-6 md:grid-cols-5">
        <Reveal className="md:col-span-3">
          <div className="glass rounded-3xl p-8">
            <p className="text-lg leading-relaxed text-ink/90">{profile.bio}</p>
            <p className="mt-4 text-sm text-muted">{profile.location}</p>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-4">
            {highlights.map((h) => (
              <div key={h.title} className="glass rounded-2xl p-5">
                <div className="mb-3 flex h-9 w-9 items-center justify-center rounded-full bg-violet/15 text-violet-soft">
                  {h.icon}
                </div>
                <h3 className="font-display text-sm font-semibold">{h.title}</h3>
                <p className="mt-1 text-xs text-muted">{h.text}</p>
              </div>
            ))}
          </div>
        </Reveal>

        <Reveal delay={0.15} className="md:col-span-2">
          <div className="glass grid h-full grid-cols-2 gap-6 rounded-3xl p-8">
            {profile.stats.map((s) => (
              <div key={s.label} className="flex flex-col items-start">
                <Counter value={s.value} suffix={s.suffix} />
                <span className="mt-1 text-xs text-muted">{s.label}</span>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
