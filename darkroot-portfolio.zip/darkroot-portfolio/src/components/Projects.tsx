import { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiGithub, FiExternalLink, FiX } from 'react-icons/fi';
import { projects } from '../data/config';
import { Reveal, SectionHeading } from './Reveal';

type Project = (typeof projects)[number];

const allTags = Array.from(new Set(projects.flatMap((p) => p.tags)));

function ProjectCard({ project, onOpen }: { project: Project; onOpen: (p: Project) => void }) {
  function handleMove(e: React.MouseEvent<HTMLDivElement>) {
    const el = e.currentTarget;
    const rect = el.getBoundingClientRect();
    const x = (e.clientX - rect.left - rect.width / 2) / rect.width;
    const y = (e.clientY - rect.top - rect.height / 2) / rect.height;
    el.style.transform = `perspective(900px) rotateX(${-y * 6}deg) rotateY(${x * 6}deg)`;
  }
  function reset(e: React.MouseEvent<HTMLDivElement>) {
    e.currentTarget.style.transform = 'perspective(900px) rotateX(0) rotateY(0)';
  }

  return (
    <div
      onMouseMove={handleMove}
      onMouseLeave={reset}
      className="glass group cursor-pointer overflow-hidden rounded-3xl transition-shadow duration-300 hover:shadow-glow"
      style={{ transition: 'transform 0.2s ease-out' }}
      onClick={() => onOpen(project)}
    >
      <div className="relative aspect-video w-full overflow-hidden bg-panel">
        <div className="skeleton absolute inset-0" />
        <img
          src={project.image}
          alt={project.title}
          loading="lazy"
          className="relative z-10 h-full w-full object-cover opacity-0 transition-opacity duration-500"
          onLoad={(e) => (e.currentTarget.style.opacity = '1')}
        />
        {project.featured && (
          <span className="absolute left-3 top-3 z-20 rounded-full bg-violet/80 px-2.5 py-1 text-[10px] font-medium text-white">
            Featured
          </span>
        )}
      </div>
      <div className="p-6">
        <h3 className="font-display text-lg font-semibold">{project.title}</h3>
        <p className="mt-2 line-clamp-2 text-sm text-muted">{project.description}</p>
        <div className="mt-4 flex flex-wrap gap-2">
          {project.tags.map((t) => (
            <span key={t} className="rounded-full bg-white/5 px-2.5 py-1 font-mono text-[10px] text-cyan/90">
              {t}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function ProjectModal({ project, onClose }: { project: Project | null; onClose: () => void }) {
  return (
    <AnimatePresence>
      {project && (
        <motion.div
          className="fixed inset-0 z-[90] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 10 }}
            transition={{ type: 'spring', stiffness: 280, damping: 26 }}
            className="glass-strong w-full max-w-2xl overflow-hidden rounded-3xl"
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-modal="true"
          >
            <div className="relative aspect-video w-full bg-panel">
              <img src={project.image} alt={project.title} className="h-full w-full object-cover" />
              <button
                onClick={onClose}
                className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full bg-black/50 text-ink hover:bg-black/70"
                aria-label="Close preview"
              >
                <FiX />
              </button>
            </div>
            <div className="p-7">
              <h3 className="font-display text-2xl font-semibold">{project.title}</h3>
              <p className="mt-3 text-muted">{project.description}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {project.tags.map((t) => (
                  <span key={t} className="rounded-full bg-white/5 px-3 py-1 font-mono text-xs text-cyan/90">
                    {t}
                  </span>
                ))}
              </div>
              <div className="mt-6 flex gap-3">
                <a
                  href={project.demo}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2 rounded-full bg-gradient-to-r from-violet to-cyan px-5 py-2.5 text-sm font-medium text-void"
                >
                  <FiExternalLink /> Live Demo
                </a>
                <a
                  href={project.github}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2 rounded-full border border-white/15 px-5 py-2.5 text-sm hover:bg-white/5"
                >
                  <FiGithub /> GitHub
                </a>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default function Projects() {
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [visibleCount, setVisibleCount] = useState(4);
  const [selected, setSelected] = useState<Project | null>(null);

  const filtered = useMemo(() => {
    return projects.filter((p) => {
      const matchTag = !activeTag || p.tags.includes(activeTag);
      const matchQuery = p.title.toLowerCase().includes(query.toLowerCase());
      return matchTag && matchQuery;
    });
  }, [activeTag, query]);

  const visible = filtered.slice(0, visibleCount);

  return (
    <section id="projects" className="relative py-28">
      <SectionHeading eyebrow="Projects" title="Selected work" description="A mix of client work, products, and open-source tools." />

      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setActiveTag(null)}
              className={`rounded-full border px-4 py-1.5 text-xs ${
                !activeTag ? 'border-cyan/50 bg-cyan/10 text-cyan' : 'border-white/10 text-muted hover:text-ink'
              }`}
            >
              All
            </button>
            {allTags.map((tag) => (
              <button
                key={tag}
                onClick={() => setActiveTag(tag)}
                className={`rounded-full border px-4 py-1.5 text-xs ${
                  activeTag === tag ? 'border-cyan/50 bg-cyan/10 text-cyan' : 'border-white/10 text-muted hover:text-ink'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search projects…"
            className="glass w-full max-w-xs rounded-full px-4 py-2 text-sm text-ink placeholder:text-muted focus:outline-none sm:w-56"
          />
        </div>

        <div className="grid gap-6 sm:grid-cols-2">
          {visible.map((p, i) => (
            <Reveal key={p.id} delay={i * 0.06}>
              <ProjectCard project={p} onOpen={setSelected} />
            </Reveal>
          ))}
        </div>

        {visibleCount < filtered.length && (
          <div className="mt-10 flex justify-center">
            <button
              onClick={() => setVisibleCount((v) => v + 4)}
              className="rounded-full border border-white/15 px-6 py-2.5 text-sm hover:bg-white/5"
            >
              Load more
            </button>
          </div>
        )}
      </div>

      <ProjectModal project={selected} onClose={() => setSelected(null)} />
    </section>
  );
}
