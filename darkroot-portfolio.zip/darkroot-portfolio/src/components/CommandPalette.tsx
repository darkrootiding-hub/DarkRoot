import { useEffect, useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { navLinks, projects, socials } from '../data/config';

interface CommandItem {
  id: string;
  label: string;
  hint?: string;
  action: () => void;
}

export default function CommandPalette({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [query, setQuery] = useState('');

  useEffect(() => {
    if (!open) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose();
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  const items: CommandItem[] = useMemo(() => {
    const navItems = navLinks.map((n) => ({
      id: `nav-${n.href}`,
      label: `Go to ${n.label}`,
      hint: 'Section',
      action: () => {
        document.querySelector(n.href)?.scrollIntoView({ behavior: 'smooth' });
        onClose();
      },
    }));
    const projectItems = projects.map((p) => ({
      id: `proj-${p.id}`,
      label: `Open project — ${p.title}`,
      hint: 'Project',
      action: () => {
        window.open(p.demo, '_blank');
        onClose();
      },
    }));
    const socialItems = socials.map((s) => ({
      id: `soc-${s.name}`,
      label: `Visit ${s.name}`,
      hint: 'Social',
      action: () => {
        window.open(s.url, '_blank');
        onClose();
      },
    }));
    return [...navItems, ...projectItems, ...socialItems];
  }, [onClose]);

  const filtered = items.filter((i) => i.label.toLowerCase().includes(query.toLowerCase()));

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[90] flex items-start justify-center bg-black/60 pt-28 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.98 }}
            transition={{ type: 'spring', stiffness: 300, damping: 26 }}
            className="glass-strong w-full max-w-lg overflow-hidden rounded-2xl"
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-label="Command palette"
          >
            <input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search sections, projects, socials…"
              className="w-full border-b border-white/10 bg-transparent px-5 py-4 text-ink placeholder:text-muted focus:outline-none"
            />
            <ul className="max-h-80 overflow-y-auto p-2">
              {filtered.length === 0 && (
                <li className="px-4 py-3 text-sm text-muted">No results.</li>
              )}
              {filtered.map((item) => (
                <li key={item.id}>
                  <button
                    onClick={item.action}
                    className="flex w-full items-center justify-between rounded-xl px-4 py-3 text-left text-sm text-ink/90 hover:bg-white/5"
                  >
                    <span>{item.label}</span>
                    {item.hint && <span className="font-mono text-xs text-muted">{item.hint}</span>}
                  </button>
                </li>
              ))}
            </ul>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
