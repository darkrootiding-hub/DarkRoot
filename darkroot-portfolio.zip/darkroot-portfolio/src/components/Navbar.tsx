import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { navLinks, profile } from '../data/config';
import { useScrollProgress, useActiveSection } from '../hooks/useScrollProgress';

export default function Navbar({ onOpenCommandPalette }: { onOpenCommandPalette: () => void }) {
  const [open, setOpen] = useState(false);
  const progress = useScrollProgress();
  const active = useActiveSection(navLinks.map((l) => l.href.replace('#', '')));

  return (
    <>
      {/* Scroll progress bar */}
      <div className="fixed top-0 left-0 z-50 h-[2px] w-full bg-transparent">
        <div
          className="h-full bg-gradient-to-r from-violet to-cyan transition-[width] duration-150"
          style={{ width: `${progress * 100}%` }}
        />
      </div>

      <header className="fixed top-0 left-0 z-40 w-full">
        <nav className="glass mx-auto mt-3 flex max-w-6xl items-center justify-between rounded-2xl px-5 py-3 md:mt-4">
          <a href="#home" className="font-display text-lg tracking-wide">
            {profile.name.split(' ')[0]}<span className="text-gradient">.</span>
          </a>

          <ul className="hidden items-center gap-1 md:flex">
            {navLinks.map((link) => {
              const isActive = active === link.href.replace('#', '');
              return (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className={`relative rounded-full px-3.5 py-2 text-sm transition-colors ${
                      isActive ? 'text-ink' : 'text-muted hover:text-ink'
                    }`}
                  >
                    {isActive && (
                      <motion.span
                        layoutId="nav-pill"
                        className="absolute inset-0 rounded-full bg-white/8 border border-white/10"
                        transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                      />
                    )}
                    <span className="relative z-10">{link.label}</span>
                  </a>
                </li>
              );
            })}
          </ul>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenCommandPalette}
              className="hidden items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-muted hover:text-ink md:flex"
              aria-label="Open command palette"
            >
              Search
              <kbd className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-[10px]">Ctrl K</kbd>
            </button>

            <button
              className="rounded-full border border-white/10 p-2 md:hidden"
              onClick={() => setOpen((v) => !v)}
              aria-label="Toggle menu"
              aria-expanded={open}
            >
              <div className="flex h-4 w-5 flex-col justify-between">
                <motion.span animate={{ rotate: open ? 45 : 0, y: open ? 7 : 0 }} className="h-[2px] w-full bg-ink" />
                <motion.span animate={{ opacity: open ? 0 : 1 }} className="h-[2px] w-full bg-ink" />
                <motion.span animate={{ rotate: open ? -45 : 0, y: open ? -7 : 0 }} className="h-[2px] w-full bg-ink" />
              </div>
            </button>
          </div>
        </nav>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="glass-strong fixed left-4 right-4 top-20 z-40 rounded-2xl p-4 md:hidden"
          >
            <ul className="flex flex-col gap-1">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={() => setOpen(false)}
                    className="block rounded-xl px-4 py-3 text-ink/90 hover:bg-white/5"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
