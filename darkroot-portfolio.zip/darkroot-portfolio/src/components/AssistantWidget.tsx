import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiMessageCircle, FiX, FiSend } from 'react-icons/fi';

interface Message {
  role: 'user' | 'assistant';
  text: string;
}

const STARTER: Message[] = [
  { role: 'assistant', text: "Hi! I'm a placeholder assistant. Wire me up to your favorite LLM API to answer questions about David's work." },
];

/**
 * Front-end shell for an AI assistant widget. Not connected to a backend —
 * replace `handleSend` with a call to your API of choice (OpenAI, Anthropic, etc).
 */
export default function AssistantWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>(STARTER);
  const [input, setInput] = useState('');

  function handleSend(e: React.FormEvent) {
    e.preventDefault();
    if (!input.trim()) return;
    const userMsg: Message = { role: 'user', text: input };
    setMessages((m) => [...m, userMsg]);
    setInput('');
    setTimeout(() => {
      setMessages((m) => [
        ...m,
        { role: 'assistant', text: 'This is a demo response. Connect an API in AssistantWidget.tsx to make me real.' },
      ]);
    }, 600);
  }

  return (
    <>
      <motion.button
        onClick={() => setOpen((v) => !v)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="fixed bottom-6 right-6 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-violet to-cyan text-void shadow-glow"
        aria-label="Open AI assistant"
      >
        {open ? <FiX size={22} /> : <FiMessageCircle size={22} />}
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="glass-strong fixed bottom-24 right-6 z-40 flex h-96 w-80 flex-col overflow-hidden rounded-2xl"
          >
            <div className="border-b border-white/10 px-4 py-3">
              <p className="font-display text-sm font-semibold">Ask about David</p>
            </div>
            <div className="flex-1 space-y-3 overflow-y-auto p-4">
              {messages.map((m, i) => (
                <div
                  key={i}
                  className={`max-w-[85%] rounded-xl px-3 py-2 text-xs ${
                    m.role === 'assistant' ? 'bg-white/5 text-ink/90' : 'ml-auto bg-cyan/15 text-ink'
                  }`}
                >
                  {m.text}
                </div>
              ))}
            </div>
            <form onSubmit={handleSend} className="flex gap-2 border-t border-white/10 p-3">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type a message…"
                className="flex-1 rounded-full bg-white/5 px-3 py-2 text-xs text-ink outline-none"
              />
              <button type="submit" className="flex h-8 w-8 items-center justify-center rounded-full bg-cyan text-void">
                <FiSend size={14} />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
