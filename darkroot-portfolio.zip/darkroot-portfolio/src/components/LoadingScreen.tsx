import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

/** Full-screen loading sequence shown once on first mount. */
export default function LoadingScreen({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = useState(0);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const start = performance.now();
    const duration = 1400;

    function tick(now: number) {
      const p = Math.min(1, (now - start) / duration);
      setProgress(p);
      if (p < 1) {
        requestAnimationFrame(tick);
      } else {
        setTimeout(() => {
          setVisible(false);
          setTimeout(onDone, 500);
        }, 200);
      }
    }
    const raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [onDone]);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-void"
          exit={{ opacity: 0, transition: { duration: 0.5 } }}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            className="font-display text-2xl tracking-[0.3em] text-ink"
          >
            DARK<span className="text-gradient">ROOT</span>
          </motion.div>
          <div className="mt-8 h-px w-56 overflow-hidden bg-white/10">
            <motion.div
              className="h-full bg-gradient-to-r from-violet to-cyan"
              style={{ width: `${progress * 100}%` }}
            />
          </div>
          <p className="mt-4 font-mono text-xs text-muted">{Math.round(progress * 100)}%</p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
