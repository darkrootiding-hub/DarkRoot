import { blogPosts } from '../data/config';
import { Reveal, SectionHeading } from './Reveal';

export default function Blog() {
  return (
    <section id="blog" className="relative py-28">
      <SectionHeading eyebrow="Writing" title="From the blog" description="Notes on building, designing, and shipping." />
      <div className="mx-auto grid max-w-6xl gap-6 px-6 sm:grid-cols-3">
        {blogPosts.map((post, i) => (
          <Reveal key={post.id} delay={i * 0.08}>
            <a href={`#blog-${post.id}`} className="glass block h-full rounded-3xl p-6 transition-all hover:-translate-y-1 hover:shadow-glow">
              <span className="rounded-full bg-white/5 px-2.5 py-1 font-mono text-[10px] text-cyan">{post.tag}</span>
              <h3 className="mt-4 font-display text-lg font-semibold leading-snug">{post.title}</h3>
              <p className="mt-2 text-sm text-muted">{post.excerpt}</p>
              <div className="mt-5 flex items-center justify-between text-xs text-muted">
                <span>{new Date(post.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                <span>{post.readTime}</span>
              </div>
            </a>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
