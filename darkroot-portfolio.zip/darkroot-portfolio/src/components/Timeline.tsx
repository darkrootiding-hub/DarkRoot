import { useState } from 'react';
import { motion } from 'framer-motion';
import { FiBriefcase, FiBookOpen, FiAward, FiStar, FiChevronDown } from 'react-icons/fi';
import { timeline, TimelineType } from '../data/config';
import { Reveal, SectionHeading } from './Reveal';

const typeIcon: Record<TimelineType, JSX.Element> = {
  experience: <FiBriefcase />,
  education: <FiBookOpen />,
  certification: <FiAward />,
  award: <FiStar />,
};

const typeLabel: Record<TimelineType, string> = {
  experience: 'Experience',
  education: 'Education',
  certification: 'Certification',
  award: 'Award',
};

export default function Timeline() {
  const [openId, setOpenId] = useState<string | null>(timeline[0]?.id ?? null);

  return (
    <section id="experience" className="relative py-28">
      <SectionHeading eyebrow="Journey" title="Experience & Milestones" />

      <div className="mx-auto max-w-3xl px-6">
        <div className="relative border-l border-white/10 pl-8">
          <motion.div
            className="absolute left-0 top-0 h-full w-px bg-gradient-to-b from-violet via-cyan to-transparent"
            initial={{ scaleY: 0 }}
            whileInView={{ scaleY: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1.2, ease: 'easeOut' }}
            style={{ transformOrigin: 'top' }}
          />

          <div className="flex flex-col gap-8">
            {timeline.map((item, i) => {
              const isOpen = openId === item.id;
              return (
                <Reveal key={item.id} delay={i * 0.08} className="relative">
                  <span className="absolute -left-[42px] top-1 flex h-6 w-6 items-center justify-center rounded-full bg-void text-xs text-cyan shadow-cyanGlow ring-1 ring-cyan/40">
                    {typeIcon[item.type]}
                  </span>

                  <button
                    onClick={() => setOpenId(isOpen ? null : item.id)}
                    className="glass w-full rounded-2xl p-5 text-left transition-shadow hover:shadow-glow"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <p className="font-mono text-[11px] uppercase tracking-wider text-cyan">
                          {typeLabel[item.type]} · {item.period}
                        </p>
                        <h3 className="mt-1 font-display text-lg font-semibold">{item.title}</h3>
                        <p className="text-sm text-muted">{item.org}</p>
                      </div>
                      <motion.span animate={{ rotate: isOpen ? 180 : 0 }} className="mt-1 text-muted">
                        <FiChevronDown />
                      </motion.span>
                    </div>
                    <motion.div
                      initial={false}
                      animate={{ height: isOpen ? 'auto' : 0, opacity: isOpen ? 1 : 0 }}
                      className="overflow-hidden"
                    >
                      <p className="mt-3 text-sm text-ink/80">{item.description}</p>
                    </motion.div>
                  </button>
                </Reveal>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
