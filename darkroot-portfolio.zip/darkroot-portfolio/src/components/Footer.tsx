import { profile, socials, navLinks } from '../data/config';

export default function Footer() {
  return (
    <footer className="relative border-t border-white/5 py-12">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-6 px-6 text-center">
        <div className="font-display text-lg tracking-wide">
          DARK<span className="text-gradient">ROOT</span>
        </div>
        <ul className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-xs text-muted">
          {navLinks.map((l) => (
            <li key={l.href}>
              <a href={l.href} className="hover:text-ink">
                {l.label}
              </a>
            </li>
          ))}
        </ul>
        <div className="flex gap-4 text-muted">
          {socials.map((s) => (
            <a key={s.name} href={s.url} target="_blank" rel="noreferrer" className="hover:text-cyan">
              {s.name}
            </a>
          ))}
        </div>
        <p className="text-xs text-muted">
          © {new Date().getFullYear()} {profile.name} · {profile.brand}. Built with React, Three.js & Framer Motion.
        </p>
      </div>
    </footer>
  );
}
