import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiCheck, FiCopy, FiSend } from 'react-icons/fi';
import { profile, socials } from '../data/config';
import { Reveal, SectionHeading } from './Reveal';

interface FormState {
  name: string;
  email: string;
  message: string;
}

function FloatingField({
  label,
  value,
  onChange,
  type = 'text',
  error,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  error?: string;
}) {
  const [focused, setFocused] = useState(false);
  const active = focused || value.length > 0;
  const Field = type === 'textarea' ? 'textarea' : 'input';

  return (
    <div className="relative">
      <Field
        value={value}
        onChange={(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => onChange(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        rows={type === 'textarea' ? 4 : undefined}
        className={`w-full rounded-xl border bg-white/5 px-4 pb-2.5 pt-5 text-sm text-ink outline-none transition-colors ${
          error ? 'border-red-400/60' : 'border-white/10 focus:border-cyan/50'
        }`}
      />
      <motion.label
        animate={{
          top: active ? 8 : '50%',
          fontSize: active ? '0.7rem' : '0.875rem',
          y: active ? 0 : '-50%',
          color: active ? '#3fd0ff' : '#8b93ad',
        }}
        className="pointer-events-none absolute left-4"
      >
        {label}
      </motion.label>
      {error && <p className="mt-1 text-xs text-red-400">{error}</p>}
    </div>
  );
}

export default function Contact() {
  const [form, setForm] = useState<FormState>({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState<Partial<FormState>>({});
  const [submitted, setSubmitted] = useState(false);
  const [copied, setCopied] = useState(false);

  function validate(): boolean {
    const next: Partial<FormState> = {};
    if (!form.name.trim()) next.name = 'Please enter your name.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) next.email = 'Enter a valid email.';
    if (form.message.trim().length < 10) next.message = 'Message should be at least 10 characters.';
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    // In production: send to your backend / email service here.
    setSubmitted(true);
    setForm({ name: '', email: '', message: '' });
    setTimeout(() => setSubmitted(false), 4000);
  }

  function copyEmail() {
    navigator.clipboard.writeText(profile.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <section id="contact" className="relative py-28">
      <SectionHeading eyebrow="Contact" title="Let's build something" description="Have a project in mind? I'd love to hear about it." />

      <div className="mx-auto grid max-w-5xl gap-8 px-6 md:grid-cols-5">
        <Reveal className="md:col-span-2">
          <div className="glass flex h-full flex-col justify-between rounded-3xl p-8">
            <div>
              <h3 className="font-display text-lg font-semibold">Direct contact</h3>
              <button
                onClick={copyEmail}
                className="mt-3 flex items-center gap-2 text-sm text-muted hover:text-cyan"
              >
                {profile.email}
                {copied ? <FiCheck className="text-cyan" /> : <FiCopy />}
              </button>
              <p className="mt-4 text-xs text-muted">{profile.location}</p>
            </div>

            <div className="mt-8 flex flex-wrap gap-3">
              {socials.map((s) => (
                <a
                  key={s.name}
                  href={s.url}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-full border border-white/10 px-3.5 py-1.5 text-xs text-muted hover:border-cyan/40 hover:text-cyan"
                >
                  {s.name}
                </a>
              ))}
            </div>
          </div>
        </Reveal>

        <Reveal delay={0.1} className="md:col-span-3">
          <form onSubmit={handleSubmit} className="glass relative overflow-hidden rounded-3xl p-8">
            <div className="flex flex-col gap-5">
              <FloatingField label="Your name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} error={errors.name} />
              <FloatingField label="Your email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} error={errors.email} />
              <FloatingField
                label="Your message"
                value={form.message}
                onChange={(v) => setForm({ ...form, message: v })}
                type="textarea"
                error={errors.message}
              />
              <button
                type="submit"
                className="flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-violet to-cyan px-6 py-3 text-sm font-medium text-void"
              >
                <FiSend /> Send message
              </button>
            </div>

            <AnimatePresence>
              {submitted && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="glass-strong absolute inset-0 flex flex-col items-center justify-center rounded-3xl text-center"
                >
                  <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-cyan/15 text-cyan">
                    <FiCheck size={24} />
                  </div>
                  <p className="font-display text-lg font-semibold">Message sent</p>
                  <p className="mt-1 text-sm text-muted">Thanks for reaching out — I'll reply soon.</p>
                </motion.div>
              )}
            </AnimatePresence>
          </form>
        </Reveal>
      </div>
    </section>
  );
}
