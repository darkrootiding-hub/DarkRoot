import { FiAward, FiStar } from 'react-icons/fi';
import { timeline } from '../data/config';
import { Reveal, SectionHeading } from './Reveal';

export default function Certifications() {
  const items = timeline.filter((t) => t.type === 'certification' || t.type === 'award');

  return (
    <section id="certifications" className="relative py-28">
      <SectionHeading eyebrow="Recognition" title="Certifications & Awards" />
      <div className="mx-auto grid max-w-4xl gap-5 px-6 sm:grid-cols-2">
        {items.map((item, i) => (
          <Reveal key={item.id} delay={i * 0.08}>
            <div className="glass flex gap-4 rounded-2xl p-6 transition-shadow hover:shadow-glow">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-violet/15 text-lg text-violet-soft">
                {item.type === 'certification' ? <FiAward /> : <FiStar />}
              </div>
              <div>
                <h3 className="font-display text-base font-semibold">{item.title}</h3>
                <p className="mt-1 text-xs text-muted">{item.org} · {item.period}</p>
                <p className="mt-2 text-sm text-ink/80">{item.description}</p>
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
