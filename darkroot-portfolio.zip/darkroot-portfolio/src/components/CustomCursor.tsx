import { useEffect, useRef, useState } from 'react';

/** Custom glowing cursor that follows the pointer with slight inertia. Desktop only. */
export default function CustomCursor() {
  const dotRef = useRef<HTMLDivElement>(null);
  const glowRef = useRef<HTMLDivElement>(null);
  const [isTouch, setIsTouch] = useState(false);
  const [isPointer, setIsPointer] = useState(false);

  useEffect(() => {
    setIsTouch(window.matchMedia('(pointer: coarse)').matches);

    const pos = { x: 0, y: 0 };
    const glow = { x: 0, y: 0 };

    function onMove(e: MouseEvent) {
      pos.x = e.clientX;
      pos.y = e.clientY;
      if (dotRef.current) {
        dotRef.current.style.transform = `translate3d(${pos.x}px, ${pos.y}px, 0)`;
      }
      const target = e.target as HTMLElement;
      setIsPointer(!!target.closest('a, button, [role="button"], input, textarea'));
    }

    let raf: number;
    function loop() {
      glow.x += (pos.x - glow.x) * 0.15;
      glow.y += (pos.y - glow.y) * 0.15;
      if (glowRef.current) {
        glowRef.current.style.transform = `translate3d(${glow.x}px, ${glow.y}px, 0)`;
      }
      raf = requestAnimationFrame(loop);
    }

    window.addEventListener('mousemove', onMove);
    raf = requestAnimationFrame(loop);
    return () => {
      window.removeEventListener('mousemove', onMove);
      cancelAnimationFrame(raf);
    };
  }, []);

  if (isTouch) return null;

  return (
    <>
      <div
        ref={glowRef}
        className="pointer-events-none fixed left-0 top-0 z-[100] -translate-x-1/2 -translate-y-1/2 rounded-full mix-blend-screen transition-[width,height] duration-200 ease-out hidden md:block"
        style={{
          width: isPointer ? 56 : 32,
          height: isPointer ? 56 : 32,
          background: 'radial-gradient(circle, rgba(109,91,255,0.5) 0%, rgba(63,208,255,0.15) 60%, transparent 70%)',
        }}
      />
      <div
        ref={dotRef}
        className="pointer-events-none fixed left-0 top-0 z-[100] h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan hidden md:block"
      />
    </>
  );
}
