import { useMemo, useState, useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { skills, SkillCategory } from '../data/config';
import { Reveal, SectionHeading } from './Reveal';

const categories: (SkillCategory | 'All')[] = ['All', 'Frontend', 'Backend', 'AI & Data', 'Tools & Platforms'];

function SkillRing({ level }: { level: number }) {
  const ref = useRef<SVGSVGElement>(null);
  const inView = useInView(ref, { once: true });
  const radius = 34;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (level / 100) * circumference;

  return (
    <svg ref={ref} width="84" height="84" viewBox="0 0 84 84" className="shrink-0">
      <circle cx="42" cy="42" r={radius} stroke="rgba(255,255,255,0.08)" strokeWidth="6" fill="none" />
      <motion.circle
        cx="42"
        cy="42"
        r={radius}
        stroke="url(#ring-gradient)"
        strokeWidth="6"
        fill="none"
        strokeLinecap="round"
        strokeDasharray={circumference}
        initial={{ strokeDashoffset: circumference }}
        animate={{ strokeDashoffset: inView ? offset : circumference }}
        transition={{ duration: 1.2, ease: 'easeOut' }}
        transform="rotate(-90 42 42)"
      />
      <defs>
        <linearGradient id="ring-gradient" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#6d5bff" />
          <stop offset="100%" stopColor="#3fd0ff" />
        </linearGradient>
      </defs>
      <text x="42" y="47" textAnchor="middle" className="fill-ink font-mono text-sm">
        {level}
      </text>
    </svg>
  );
}

function SkillCard({ name, level }: { name: string; level: number }) {
  function handleMove(e: React.MouseEvent<HTMLDivElement>) {
    const el = e.currentTarget;
    const rect = el.getBoundingClientRect();
    const x = (e.clientX - rect.left - rect.width / 2) / rect.width;
    const y = (e.clientY - rect.top - rect.height / 2) / rect.height;
    el.style.transform = `perspective(600px) rotateX(${-y * 10}deg) rotateY(${x * 10}deg) translateZ(4px)`;
  }
  function reset(e: React.MouseEvent<HTMLDivElement>) {
    e.currentTarget.style.transform = 'perspective(600px) rotateX(0) rotateY(0)';
  }

  return (
    <div
      onMouseMove={handleMove}
      onMouseLeave={reset}
      className="glass flex flex-col items-center gap-3 rounded-2xl p-6 transition-shadow duration-300 hover:shadow-glow"
      style={{ transition: 'transform 0.2s ease-out' }}
    >
      <SkillRing level={level} />
      <span className="text-sm font-medium text-ink/90">{name}</span>
    </div>
  );
}

export default function Skills() {
  const [filter, setFilter] = useState<(typeof categories)[number]>('All');
  const [query, setQuery] = useState('');

  const filtered = useMemo(() => {
    return skills.filter((s) => {
      const matchCat = filter === 'All' || s.category === filter;
      const matchQuery = s.name.toLowerCase().includes(query.toLowerCase());
      return matchCat && matchQuery;
    });
  }, [filter, query]);

  return (
    <section id="skills" className="relative py-28">
      <SectionHeading eyebrow="Skills" title="Tools I build with" description="A living toolkit — updated as I learn." />

      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-8 flex flex-col items-center gap-4 sm:flex-row sm:justify-between">
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setFilter(c)}
                className={`rounded-full border px-4 py-1.5 text-xs transition-colors ${
                  filter === c
                    ? 'border-cyan/50 bg-cyan/10 text-cyan'
                    : 'border-white/10 text-muted hover:text-ink'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search skills…"
            className="glass w-full max-w-xs rounded-full px-4 py-2 text-sm text-ink placeholder:text-muted focus:outline-none sm:w-56"
          />
        </div>

        <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-5">
          {filtered.map((s, i) => (
            <Reveal key={s.name} delay={i * 0.04}>
              <SkillCard name={s.name} level={s.level} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
