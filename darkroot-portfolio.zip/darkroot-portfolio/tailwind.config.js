/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        void: '#05060a',
        panel: '#0b0e1a',
        panel2: '#10142450',
        ink: '#e8ebf5',
        muted: '#8b93ad',
        violet: {
          DEFAULT: '#6d5bff',
          soft: '#9d8dff',
          deep: '#3d2fbd',
        },
        cyan: {
          DEFAULT: '#3fd0ff',
          soft: '#8ee9ff',
        },
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      backgroundImage: {
        'root-glow': 'radial-gradient(circle at 50% 30%, rgba(109,91,255,0.25), transparent 60%)',
        'aurora': 'linear-gradient(120deg, rgba(109,91,255,0.18), rgba(63,208,255,0.12), rgba(109,91,255,0.08))',
      },
      boxShadow: {
        glow: '0 0 40px rgba(109,91,255,0.35)',
        cyanGlow: '0 0 40px rgba(63,208,255,0.35)',
      },
      animation: {
        'pulse-slow': 'pulse 6s cubic-bezier(0.4,0,0.6,1) infinite',
        float: 'float 6s ease-in-out infinite',
        'float-delay': 'float 7s ease-in-out infinite 1s',
        marquee: 'marquee 30s linear infinite',
      },
      keyframes: {
        float: {
          '0%,100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-16px)' },
        },
        marquee: {
          '0%': { transform: 'translateX(0)' },
          '100%': { transform: 'translateX(-50%)' },
        },
      },
    },
  },
  plugins: [],
};
